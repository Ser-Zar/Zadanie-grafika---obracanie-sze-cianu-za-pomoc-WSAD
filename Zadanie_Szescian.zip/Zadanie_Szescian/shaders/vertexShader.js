const vertexShaderTxt = `
precision mediump float;

uniform mat4 mModel; //rotacja, skalowanie
uniform mat4 mView;  //gdzie patrzy kamera
uniform mat4 mProj;  //jak działa soczewka

attribute vec3 vertPosition;
attribute vec3 vertColor;

varying vec3 fragColor;

void main() {
    fragColor = vertColor;
    gl_Position = mProj * mView * mModel * vec4(vertPosition, 1.0);
}
`
// uniform are per-primitive parameters (constant during an entire draw call) ;
// attribute are per-vertex parameters (typically : positions, normals, colors, UVs, ...) ;
// varying are per-fragment (or per-pixel) parameters : they vary from pixels to pixels.