const Triangle = function () {
    let canvas_color = [0.25, 0.44, 0.8]; // RGB
    const canvas = document.getElementById('main-canvas');
    const gl = canvas.getContext('webgl2');
    
    gl.clearColor(...canvas_color, 1.0);   // rgba
    gl.clear(gl.COLOR_BUFFER_BIT);

    const vertexShader = gl.createShader(gl.VERTEX_SHADER);
    const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);

    gl.shaderSource(vertexShader, vertexShaderTxt);
    gl.shaderSource(fragmentShader, fragmentShaderTxt);

    gl.compileShader(vertexShader);
    gl.compileShader(fragmentShader);

    const program = gl.createProgram();

    gl.attachShader(program, vertexShader);     
    gl.attachShader(program, fragmentShader);

    gl.linkProgram(program);
    gl.validateProgram(program);
    
    function checkShaderCompile(shader) {
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
            console.error('shader not compiled', gl.getShaderInfoLog(shader));
        }
    }
    
    function checkLink(program) {
        if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
            console.error('ERROR linking program!', gl.getProgramInfoLog(program));
        }
    }

   const boxVertices = 
[ // X, Y, Z         
	// Top
	-1.0, 1.0, -1.0,    
	-1.0, 1.0, 1.0,     
	1.0, 1.0, 1.0,      
	1.0, 1.0, -1.0,     

	// Left
	-1.0, 1.0, 1.0,     
	-1.0, -1.0, 1.0,    
	-1.0, -1.0, -1.0,   
	-1.0, 1.0, -1.0,    

	// Right
	1.0, 1.0, 1.0,      
	1.0, -1.0, 1.0,     
	1.0, -1.0, -1.0,    
	1.0, 1.0, -1.0,     

	// Front
	1.0, 1.0, 1.0,      
	1.0, -1.0, 1.0,     
	-1.0, -1.0, 1.0,    
	-1.0, 1.0, 1.0,     

	// Back
	1.0, 1.0, -1.0,     
	1.0, -1.0, -1.0,    
	-1.0, -1.0, -1.0,   
	-1.0, 1.0, -1.0,    

	// Bottom
	-1.0, -1.0, -1.0,   
	-1.0, -1.0, 1.0,    
	1.0, -1.0, 1.0,     
	1.0, -1.0, -1.0,    
];

const boxIndices =
[
	// Top
	0, 1, 2,
	0, 2, 3,

	// Left
	5, 4, 6,
	6, 4, 7,

	// Right
	8, 9, 10,
	8, 10, 11,

	// Front
	13, 12, 14,
	15, 14, 12,

	// Back
	16, 17, 18,
	16, 18, 19,

	// Bottom
	21, 20, 22,
	22, 20, 23,
];

let colors = 
[  
	1.0, 0.0, 0.0,
	0.0, 1.0, 0.0,
	0.0, 0.2, 1.0,
	0.5, 1.0, 0.0,

	0.8, 0.0, 0.2,
	0.0, 1.0, 1.0,
	0.0, 0.2, 1.0,
	0.5, 1.0, 0.0,

	1.0, 0.0, 0.0,
	0.0, 1.0, 0.0,
	0.0, 0.2, 1.0,
	0.5, 1.0, 0.0,

	1.0, 0.0, 0.0,
	0.0, 1.0, 0.0,
	0.0, 0.2, 1.0,
	0.5, 1.0, 0.0,

	1.0, 0.0, 0.0,
	0.0, 1.0, 0.0,
	0.0, 0.2, 1.0,
	0.5, 1.0, 0.0,

	1.0, 0.0, 0.0,
	0.0, 1.0, 0.0,
	0.0, 0.2, 1.0,
	0.5, 1.0, 0.0,
]

    const triangleBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, triangleBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(boxVertices), gl.STATIC_DRAW);

    const posAttribLocation = gl.getAttribLocation(program, 'vertPosition');
    gl.vertexAttribPointer(
        posAttribLocation,
        3, 
        gl.FLOAT, 
        0,      
        3*Float32Array.BYTES_PER_ELEMENT,
        0, 
    );
    gl.enableVertexAttribArray(posAttribLocation);

    const squareIndexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, squareIndexBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(boxIndices), gl.STATIC_DRAW);

    const colorAttribLocation = gl.getAttribLocation(program, 'vertColor');
    const colorBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(colors), gl.STATIC_DRAW);
    gl.vertexAttribPointer(
        colorAttribLocation,
        3,         
        gl.FLOAT,
        0,
        3*Float32Array.BYTES_PER_ELEMENT,
        0,
    );
    gl.enableVertexAttribArray(colorAttribLocation);

    gl.useProgram(program);     
    
    const modelMatrix = gl.getUniformLocation(program, 'mModel');
    const viewMatrix = gl.getUniformLocation(program, 'mView');
    const projMatrix = gl.getUniformLocation(program, 'mProj');

    const glm = glMatrix;
    let mMod = glm.mat4.create();
    let mView = glm.mat4.create();
    glm.mat4.lookAt(mView, [0,0,-5], [0,0,0], [0,1,0]); 
    let mProj = glm.mat4.create();
    glm.mat4.perspective(mProj, glm.glMatrix.toRadian(90), canvas.width/canvas.height, 0.1, 1000.0);

    gl.uniformMatrix4fv(modelMatrix, gl.FALSE, mMod);
    gl.uniformMatrix4fv(viewMatrix, gl.FALSE, mView);
    gl.uniformMatrix4fv(projMatrix, gl.FALSE, mProj);

    // --- ZMIENNE STEROWANIA KLAWIATURĄ (wewnątrz funkcji Triangle) ---
    let angleX = 0;
    let angleY = 0;
    const rotationSpeed = 0.03;
    const pressedKeys = {};

    window.addEventListener('keydown', (e) => {
        pressedKeys[e.key.toLowerCase()] = true;
    });

    window.addEventListener('keyup', (e) => {
        pressedKeys[e.key.toLowerCase()] = false;
    });

    const loop = function () {
        // Sprawdzanie wciśniętych klawiszy (WASD / Strzałki)
        if (pressedKeys['w'] || pressedKeys['arrowup'])    angleX += rotationSpeed;
        if (pressedKeys['s'] || pressedKeys['arrowdown'])  angleX -= rotationSpeed;
        if (pressedKeys['a'] || pressedKeys['arrowleft'])  angleY += rotationSpeed;
        if (pressedKeys['d'] || pressedKeys['arrowright']) angleY -= rotationSpeed;

        // WYMAGANIE ZADANIA: Zgodnie z podpowiedzią używamy mat4.rotate z identityMat
        let identityMat = glm.mat4.create();
        glm.mat4.identity(identityMat);
        
        // Łączymy obroty w dwóch płaszczyznach naraz
        glm.mat4.rotate(mMod, identityMat, angleX, [1, 0, 0]); // Płaszczyzna X
        glm.mat4.rotate(mMod, mMod, angleY, [0, 1, 0]);        // Płaszczyzna Y

        // Przekazanie macierzy do shaderów
        gl.uniformMatrix4fv(modelMatrix, gl.FALSE, mMod);

        // Renderowanie klatki
        gl.clearColor(...canvas_color, 1.0);
        gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
        
        gl.enable(gl.DEPTH_TEST);
        gl.enable(gl.CULL_FACE);
        gl.frontFace(gl.CW);
        gl.cullFace(gl.FRONT);

        gl.drawElements(gl.TRIANGLES, boxIndices.length, gl.UNSIGNED_SHORT, 0);

        requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
};